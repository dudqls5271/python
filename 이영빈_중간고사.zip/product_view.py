from product import *
import product
import product_selection

def te():
    print("==========================")
    product.Digital()
    product.life()
    product.Fashion()
    print("==========================")

    product_selection.product_select()

if __name__ == '__main__':
    te()

