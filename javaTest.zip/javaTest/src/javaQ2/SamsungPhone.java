package javaQ2;

public class SamsungPhone {
}
