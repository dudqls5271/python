package javaQ2;

public class XiaomiRedmi10 extends Nav{
    public void model(){
        String phoneModel = "Xiaomi";
        System.out.println("[ 메뉴( XiaomiRedmi10 )]");
        nav(phoneModel);
    }

    public void Phoneoption(){
        System.out.println(":::::: XiaomiRedmi10 ::::::");
        System.out.println("제조사 : Xiami");
        System.out.println("모델명 : XiaomiRedmi10");
        System.out.println("가격 : 90만원");
    }
}
