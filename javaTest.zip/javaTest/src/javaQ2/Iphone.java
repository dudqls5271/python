package javaQ2;

public class Iphone {

}
