package javaQ2;

public class Iphone12Pro extends Nav {
    public void model(){
        String phoneModel = "Iphone";
        System.out.println( "[ 메뉴( 아이폰12Pro )]");
        nav(phoneModel);
    }

    public void Phoneoption(){
        System.out.println("::::::  아이폰 12Pro  ::::::");
        System.out.println("제조사 : Apple");
        System.out.println("모델명 : 아이폰 12Pro");
        System.out.println("가격 : 160만원");
    }
}
