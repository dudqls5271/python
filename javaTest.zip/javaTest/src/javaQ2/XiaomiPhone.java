package javaQ2;

public class XiaomiPhone {
}
